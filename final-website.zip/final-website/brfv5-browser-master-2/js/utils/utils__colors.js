export const colorPrimary   = '#00a0ff'
export const colorSecondary = '#ffffff'
export const colorWhitePale = 'rgb(255, 255, 255, 0.4)'
export const colorOrange    = '#ff7900'

export default { colorPrimary, colorSecondary, colorWhitePale, colorOrange }
